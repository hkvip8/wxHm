<?php include __DIR__.'/header.php'; ?>
<div style="max-width:480px;margin:0 auto">
<h2>注册</h2>
<form method="post">
    <label>用户名<input name="username" placeholder="用户名"></label>
    <label>密码<input type="password" name="password" placeholder="密码"></label>
    <div style="margin-top:8px"><button type="submit">注册</button></div>
    </form>
</div>
<?php include __DIR__.'/footer.php'; ?>